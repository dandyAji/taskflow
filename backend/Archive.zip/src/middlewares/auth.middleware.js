import jwt from "jsonwebtoken";
import { AppError } from "../utils/error.utils.js";
import { findById } from "../repositories/user.repository.js";

export const authMiddleware = async (req, res, next) => {
    try {
        const jwtSecret = process.env.JWT_SECRET;
        const headers = req.headers.authorization;

        // 1. Cek keberadaan header
        if (!headers || !headers.startsWith("Bearer ")) {
            throw new AppError("Anda harus login terlebih dahulu", 401);
        }

        const token = headers.split(" ")[1];

        // 2. Verifikasi JWT Token
        const decode = jwt.verify(token, jwtSecret);

        // 3. Cari user berdasarkan hasil decode ID
        const currentUser = await findById(decode.id).catch((error) => {
            throw new AppError("Gagal mencari user", 500);
        });

        if (!currentUser) {
            throw new AppError("User pemilik token ini sudah tidak ada", 404);
        }

        // 4. Pasang data user ke objek request
        req.user = {
            id: currentUser.id,
            name: currentUser.name,
            email: currentUser.email,
        };

        // Lanjut ke middleware berikutnya atau ke controller
        next();
    } catch (error) {
        // 5. JIKA ADA ERROR, OPER KE NEXT!
        if (error.name === "JsonWebTokenError") {
            return next(new AppError("Token tidak valid", 401));
        }
        if (error.name === "TokenExpiredError") {
            return next(new AppError("Token sudah kedaluwarsa", 401));
        }

        // Oper error lainnya (termasuk AppError yang kita throw di atas)
        next(error);
    }
};
