'use client';

import { useAuthStore } from '../../store/authStore';
import { useRouter } from 'next/navigation';
import { authService } from '../../services/auth.service';
import { getInitials } from '../../lib/utils';
import Logo from '../ui/Logo';

export default function Navbar({ onSearch, searchValue = '' }) {
  const user = useAuthStore((s) => s.user);
  const router = useRouter();

  const handleLogout = () => {
    authService.logout();
    useAuthStore.getState().logout();
    router.push('/login');
  };

  return (
    <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <Logo />
          </div>

          {/* Search bar (desktop) */}
          {onSearch && (
            <div className="hidden sm:flex flex-1 max-w-sm mx-6 relative">
              <svg
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                value={searchValue}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Cari tugas..."
                className="w-full bg-slate-100 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm text-slate-800 placeholder-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all"
              />
            </div>
          )}

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* Avatar + logout */}
            <button
              onClick={handleLogout}
              title="Keluar"
              className="flex items-center gap-2 ml-1 group"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-xs font-bold text-white">
                {getInitials(user?.name) || 'U'}
              </div>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
