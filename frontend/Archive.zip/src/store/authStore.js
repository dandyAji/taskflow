import { create } from 'zustand';
import Cookies from 'js-cookie';
import { authService } from '../services/auth.service';

export const useAuthStore = create((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,

  /** Set user & token setelah login/register */
  setAuth: (user, token) => {
    set({ user, token, isAuthenticated: true });
  },

  /** Logout: hapus state + cookie */
  logout: () => {
    authService.logout();
    set({ user: null, token: null, isAuthenticated: false });
  },

  /** Hydrate dari cookie saat pertama kali load (opsional) */
  hydrate: (user) => {
    const token = Cookies.get('token');
    if (token && user) {
      set({ user, token, isAuthenticated: true });
    }
  },
}));
